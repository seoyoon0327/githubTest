window.onload = function () {
	// #scheduleList와 .schedule-container가 있는지 확인
    console.log(document.querySelector("#scheduleList"));
    console.log(document.querySelector(".schedule-container"));

    // [1] 월별 계약 수 차트
    new Chart(document.getElementById('monthlyChart'), {
        type: 'bar',
        data: {
            labels: ['1월', '2월', '3월', '4월', '5월', '6월', '7월', '8월', '9월', '10월', '11월', '12월'],
            datasets: [{
                label: '계약 수',
                data: [3, 7, 4, 6, 8, 5, 7, 4, 6, 8, 9, 10],
                backgroundColor: '#2D4470',
                borderRadius: 5
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: { legend: { display: false } },
            barPercentage: 0.5,
            categoryPercentage: 0.7,
            scales: {
                x: { grid: { display: false } },
                y: { beginAtZero: true, ticks: { stepSize: 1 } }
            }
        }
    });

    // [2] 상품별 계약 분포 파이 차트
    new Chart(document.getElementById('productPie'), {
        type: 'pie',
        data: {
            labels: ['실손보험', '암보험', '운전자보험'],
            datasets: [{
                data: [40, 25, 35],
                backgroundColor: ['#4299E1', '#F6AD55', '#48BB78'],
                hoverOffset: 10,
                borderColor: '#fff',
                borderWidth: 2
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false
        }
    });

    // [3] 테이블 row 클릭 이동
    const rows = document.querySelectorAll('.clickable-row');
    rows.forEach(row => {
        row.addEventListener('click', () => {
            const href = row.getAttribute('data-href');
            if (href) {
                window.location.href = href;
            }
        });
    });

    // [4] 일정 롤링 (JS 기반 + hover 시 멈춤)
    const scheduleList = document.getElementById('scheduleList');
    const scheduleWrapper = document.querySelector('.schedule-container');
    const itemHeight = 40;
    let currentIndex = 0;
    let intervalId;

    // #scheduleList와 .schedule-container가 존재하는지 확인
    if (scheduleList === null) {
        console.error("⛔ #scheduleList 요소가 존재하지 않습니다.");
        return; // #scheduleList가 없으면 이후 로직을 실행하지 않음
    }

    if (scheduleWrapper === null) {
        console.error("⛔ .schedule-container 요소가 존재하지 않습니다.");
        return; // .schedule-container가 없으면 이후 로직을 실행하지 않음
    }

    let items = scheduleList.querySelectorAll('li');

    if (items.length > 0) {
        const firstClone = items[0].cloneNode(true);
        scheduleList.appendChild(firstClone);
        items = scheduleList.querySelectorAll('li');

        function rotateSchedule() {
            currentIndex++;
            scheduleList.style.transition = 'transform 0.5s ease-in-out';
            scheduleList.style.transform = `translateY(-${itemHeight * currentIndex}px)`;

            if (currentIndex >= items.length - 1) {
                setTimeout(() => {
                    scheduleList.style.transition = 'none';
                    scheduleList.style.transform = 'translateY(0)';
                    currentIndex = 0;
                }, 500); // transition 시간과 일치
            }
        }

        function startRolling() {
            intervalId = setInterval(rotateSchedule, 3000);
        }

        function stopRolling() {
            clearInterval(intervalId);
        }

        scheduleWrapper.addEventListener('mouseenter', stopRolling);
        scheduleWrapper.addEventListener('mouseleave', startRolling);

        startRolling();
    } else {
        console.error("⛔ #scheduleList에 li 요소가 없습니다.");
    }
};
