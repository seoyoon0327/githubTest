package org.zerock.service;

import java.util.List;

import org.springframework.stereotype.Service;
import org.zerock.domain.Criteria;
import org.zerock.domain.CustomerVO;
import org.zerock.mapper.CustomerMapper;
import org.zerock.mapper.InsuredPersonMapper;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class CustomerServiceImpl implements CustomerService {

    private final CustomerMapper customerMapper;
    private final InsuredPersonMapper insuredPersonMapper;  // 🔹 추가

    @Override
    public List<CustomerVO> getList() {
        List<CustomerVO> list = customerMapper.getList(); 
        // 🔹 고객별로 피보험자 리스트 설정
        for (CustomerVO customer : list) {
            customer.setInsuredList(insuredPersonMapper.getByCustomerId(customer.getCustomer_id()));
        }

        return list;
    }

    @Override
    public CustomerVO get(String customer_id) {
        return customerMapper.read(customer_id);
    }

    @Override
    public void register(CustomerVO vo) {
        customerMapper.insert(vo);
    }

    @Override
    public boolean modify(CustomerVO vo) {
        return customerMapper.update(vo) == 1;
    }

    @Override
    public boolean remove(String customer_id) {
        return customerMapper.delete(customer_id) == 1;
    }

    @Override
    public List<CustomerVO> getList(Criteria cri) {
        List<CustomerVO> list = customerMapper.getListWithPaging(cri);
        // 🔹 페이징된 고객 리스트에도 피보험자 설정
        for (CustomerVO customer : list) {
            customer.setInsuredList(insuredPersonMapper.getByCustomerId(customer.getCustomer_id()));
        }
        return list;
    }

    @Override
    public int getTotal(Criteria cri) {
        return customerMapper.getTotalCount(cri);
    }
}
