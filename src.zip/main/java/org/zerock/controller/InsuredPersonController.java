package org.zerock.controller;

import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import org.zerock.domain.CustomerVO;
import org.zerock.domain.InsuredPersonVO;
import org.zerock.service.CustomerService;
import org.zerock.service.InsuredPersonService;

import lombok.RequiredArgsConstructor;
import lombok.extern.log4j.Log4j;

@Controller
@RequestMapping("/insuredperson")
@Log4j
@RequiredArgsConstructor
public class InsuredPersonController {

    private final InsuredPersonService insuredPersonService;
    private final CustomerService customerService; 

    // ✅ 1. 전체 피보험자 목록
    @GetMapping("/list")
    public String list(Model model) {
        List<InsuredPersonVO> list = insuredPersonService.getList();
        model.addAttribute("list", list);
        return "insuredperson/list";
    }

    // ✅ 2. 피보험자 등록 폼
    @GetMapping("/register")
    public String registerForm(Model model) {
        List<CustomerVO> customerList = customerService.getList();  
        model.addAttribute("customerList", customerList);
        return "insuredperson/register";
    }

    // ✅ 3. 피보험자 등록 처리
    @PostMapping("/register")
    public String register(InsuredPersonVO vo) {
        insuredPersonService.register(vo);
        return "redirect:/insuredperson/list";
    }

    // ✅ 4. 피보험자 상세 조회
    @GetMapping("/get")
    public String get(@RequestParam("insured_id") String insured_id, Model model) {
        InsuredPersonVO vo = insuredPersonService.get(insured_id);
        model.addAttribute("insured", vo);
        return "insuredperson/get";
    }

    // ✅ 5. 피보험자 수정 폼
    @GetMapping("/modify")
    public String modifyForm(@RequestParam("insured_id") String insured_id, Model model) {
        log.info("modify form for insured_id: " + insured_id);
        InsuredPersonVO vo = insuredPersonService.get(insured_id);
        model.addAttribute("insuredPerson", vo);
        return "insuredperson/modify";
    }

    // ✅ 6. 피보험자 수정 처리
    @PostMapping("/modify")
    public String modify(InsuredPersonVO vo, Model model) {
        boolean result = insuredPersonService.modify(vo);
        if (!result) {
            model.addAttribute("error", "수정 실패");
            return "insuredperson/modifyFail";
        }
        return "redirect:/insuredperson/list";
    }

    // ✅ 7. 피보험자 삭제 처리
    @PostMapping("/remove")
    public String remove(@RequestParam("insured_id") String insured_id) {
        insuredPersonService.remove(insured_id);
        return "redirect:/insuredperson/list";
    }

    // ✅ 8. [Ajax용] 고객 ID로 피보험자 목록 조회 (JSON 반환)
    @ResponseBody
    @GetMapping("/byCustomer")
    public List<InsuredPersonVO> getInsuredByCustomer(@RequestParam("customerId") String customerId) {
        log.info("🔍 Ajax: 고객 ID로 피보험자 조회 - customerId: " + customerId);
        return insuredPersonService.getByCustomerId(customerId);
    }

}
